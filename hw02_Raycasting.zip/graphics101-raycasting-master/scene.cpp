#include "scene.h"
#include "camera.h"
//Include all of glm here.
#include "glm/glm.hpp"

#include "debugging.h"

namespace graphics101 {

void Scene::render( Image& into_image ) {
    // Your code goes here.

    // Iterate over the pixels of the image. For each pixel:
    // 1. Use camera->getPixelUV() and camera->getRay() to create a ray3.
    // 2. Call rayColor() to get a vec3 color for that ray.
    // 3. Use into_image.pixel() to set the pixel color.
    for(int i=0;i<into_image.width();i++)
    {
        for(int j=0;j<into_image.height();j++)
        {
            vec2 uv= camera->getPixelUV(vec2(i,j),into_image.width(),into_image.height());
            ray3 r = camera->getRay(uv);
            vec3 col = rayColor(r,3);
            vec3 color=glm::clamp(col,vec3(0),vec3(1));
            into_image.pixel(i,j).r=color.r*255;
            into_image.pixel(i,j).g=color.g*255;
            into_image.pixel(i,j).b=color.b*255;
            into_image.pixel(i,j).a=255;
        }
    }
}

bool Scene::closestIntersection( const ray3& ray, Intersection& hit_out ) const {
    // Your code goes here.
    // Iterate over all the shapes, calling rayIntersect() on each.
    // In C++, a nice iterator for loop can be written as:
    // for( const ShapePtr shape: shapes ) { ... shape->rayIntersect( ... ) ... }

    Intersection hit;
    Intersection hit1;
    hit1.t =999999999;
    for( const ShapePtr shape: shapes ) {
        if(shape->rayIntersect(ray,hit))
        {
            if(hit.t<hit1.t)
                hit1=hit;
        }

    }
    if(hit1.t==999999999)
    {
        return false;
    }
    hit_out=hit1;
    if(hit_out.t>=0)
    {
        return true;
    }
    return false;
}


vec3 Scene::rayColor( const ray3& ray, int max_recursion ) const {
    // Your code goes here.

    // In this ray casting assignment, you will simply call closestIntersection(),
    // and, if there is one, return the .material.color_diffuse;
    // Otherwise, return black (0,0,0).


    assert( max_recursion >= 0 );
    const real eps = 1e-7;

    Intersection h;
    vec3 c( 0,0,0 );
    if(closestIntersection(ray,h)){
        return h.material.color_diffuse;
    }

    else
        return c;
}

}




