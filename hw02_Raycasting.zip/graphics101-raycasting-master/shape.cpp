#include "shape.h"

#include "debugging.h"

#include <vector>
#include <cmath> // std::sqrt()

namespace graphics101 {

bool Sphere::rayIntersect( const ray3& ray, Intersection& hit_out ) const {
    // Your code goes here.

    // Remember that this intersection occurs in object-space.
    // You convert the world-space ray to object-space by multipling transformInverse() * ray.p and ray.d.
    // When filling out `hit_out`, don't forget to return the resulting position and normal in world-space.
    // For the normal, that means left-multiplying the object-space normal by transpose( transformInverse() ).

    vec4 d = vec4(ray.d,0);
    vec4 p = vec4(ray.p,1);
    vec4 direction = transformInverse()*d;
    vec4 point = transformInverse()*p;


    real a = (direction.x*direction.x) + (direction.y*direction.y) + (direction.z*direction.z);
    real b =2*(( point.x*direction.x) + (point.y*direction.y) + (point.z*direction.z));
    real c = (point.x*point.x) + (point.y*point.y) + (point.z*point.z) - 1.0;

    real t=-9999;
    real t1;
    real t2;
    vec4 q;
    vec3 n;

    real radical = (b*b) - (4*a*c);
    if (radical >= 0)
    {
        t1 = ( -b + sqrt( radical ) )/( 2*a );
        t2 = ( -b - sqrt( radical ) )/( 2*a );
        if(t1>=0 && t2>=0)
        {
            t = std::min(t1,t2);
        }
        else if(t1>=0)
        {
            t=t1;
        }
        else
        {
            t=t2;
        }
        //     t = std::min(t1,t2);
        q= point+(t*direction);
        n = vec3( 2*q.x, 2*q.y, 2*q.z);
        if(t<0){
            return false;}
        else{
            hit_out.t=t;
            hit_out.material=material();
            hit_out.normal=transpose(transformInverse())*vec4(n,0);
            hit_out.position=ray.p+(t*ray.d);
            return true;
        }
    }
    else
        return false;
}

bool Plane::rayIntersect( const ray3& ray, Intersection& hit_out ) const {
    //    // Your code goes here.

    //    // Remember that this intersection occurs in object-space.
    //    // You convert the world-space ray to object-space by multipling transformInverse() * ray.p and ray.d.
    //    // When filling out `hit_out`, don't forget to return the resulting position and normal in world-space.
    //    // For the normal, that means left-multiplying the object-space normal by transpose( transformInverse() ).

    vec4 d = vec4(ray.d,0);
    vec4 p = vec4(ray.p,1);
    vec4 direction = transformInverse()*d;
    vec4 point = transformInverse()*p;
    real c = point.z;
    real b = direction.z;
    real t = -c/b;

    if(t<0){
        return false;
    }
    else
    {
        hit_out.t = t;
        hit_out.material=material();
        hit_out.position = ray.p+(t*ray.d);
        vec3 n = vec3(0,0,1);
        hit_out.normal=transpose(transformInverse())*vec4(n,0);
        return true;
    }
    //return false;
}

bool Cylinder::rayIntersect( const ray3& ray, Intersection& hit_out ) const {

    // Remember that this intersection occurs in object-space.
    // You convert the world-space ray to object-space by multipling transformInverse() * ray.p and ray.d.
    // When filling out `hit_out`, don't forget to return the resulting position and normal in world-space.
    // For the normal, that means left-multiplying the object-space normal by transpose( transformInverse() ).

    std::vector<real>ts;
    std::vector<vec4>n;
    vec4 d = vec4(ray.d,0);
    vec4 p = vec4(ray.p,1);
    vec4 direction = transformInverse()*d;
    vec4 point = transformInverse()*p;

    // z = 0 plane: F( x,y,z ) = -z

    real c1 = point.z;
    real b1 = direction.z;
    real t0 = -(c1/b1);


    if (t0 >= 0){
        vec4 q = point + (t0 * direction);
        vec4 n1 = vec4( 0, 0,-1,0);
        real temp= pow(q.x,2)+pow(q.y,2);
        if (temp<=1)
        {
            ts.push_back(t0);
            n.push_back(n1);
        }
    }


    real t1 = (1-c1)/b1;

    if (t1 >= 0){
        vec4 q = point + (t1 * direction);
        vec4 n1 = vec4( 0, 0,1,0);
        real temp= pow(q.x,2)+pow(q.y,2);
        if (temp<=1)
        {
            ts.push_back(t1);
            n.push_back(n1);
        }
    }

    real a = (direction.x*direction.x) + (direction.y*direction.y);
    real b = 2*(( point.x*direction.x) + (point.y*direction.y));
    real c = (point.x*point.x) + (point.y*point.y)- 1.0;

    real radical = pow(b,2)-(4*a*c);

    if(radical>=0){
        real t2 = (-b+sqrt(radical))/(2*a);
        vec4 q1 = point + (t2 * direction);
        vec4 n1=vec4(2*q1.x,2*q1.y,0,0);
        if(q1.z>0 && q1.z<1 && t2>=0){
            ts.push_back(t2);
            n.push_back(n1);
        }

        real t3 = (-b-sqrt(radical))/(2*a);
        vec4 q2 = point + (t3 * direction);
        vec4 n2=vec4(2*q2.x,2*q2.y,0,0);
        if(q2.z>0 && q2.z<1 && t3>=0){
            ts.push_back(t3);
            n.push_back(n2);
        }
    }

    if(!ts.empty())
    {
        real min = *min_element(ts.begin(), ts.end());
        if(min<0)
        {
            return false;

        }
        hit_out.t=min;
        hit_out.material=material();
        hit_out.position = ray.p+(min*ray.d);
        int index=min_element(ts.begin(),ts.end())-ts.begin();
        vec4 norm=n[index];
        hit_out.normal = (transpose(transformInverse()))*norm;
        return true;
    }
    return false;
}


bool Cone::rayIntersect( const ray3& ray, Intersection& hit_out ) const {
     //Your code goes here.

    // Remember that this intersection occurs in object-space.
    // You convert the world-space ray to object-space by multipling transformInverse() * ray.p and ray.d.
    // When filling out `hit_out`, don't forget to return the resulting position and normal in world-space.
    // For the normal, that means left-multiplying the object-space normal by transpose( transformInverse() ).
    std::vector<real>ts;
    std::vector<vec4>n;
    vec4 d = vec4(ray.d,0);
    vec4 p = vec4(ray.p,1);
    vec4 direction = transformInverse()*d;
    vec4 point = transformInverse()*p;

    real c1 = point.z;
    real b1 = direction.z;
    real t0 = -(c1/b1);


    if (t0 >= 0){
        vec4 q = point + (t0 * direction);
        vec4 n1 = vec4( 0, 0,-1,0);
        real temp= pow(q.x,2)+pow(q.y,2);
        if (temp<=1)
        {
            ts.push_back(t0);
            n.push_back(n1);
        }
    }

    real a = (direction.x*direction.x) + (direction.y*direction.y) - (direction.z*direction.z);
    real b = 2*(( point.x*direction.x) + (point.y*direction.y) +((1-point.z)*direction.z));
    real c = (point.x*point.x) + (point.y*point.y)- ((1-point.z)*(1-point.z));

    real radical = pow(b,2)-(4*a*c);

    if(radical>=0){
        real t2 = (-b+sqrt(radical))/(2*a);
        vec4 q1 = point + (t2 * direction);
        vec4 n1 = vec4(2*q1.x,2*q1.y,2*(1-q1.z),0);
        if(q1.z>0 && q1.z<1){
            ts.push_back(t2);
            n.push_back(n1);
        }

        real t3 = (-b-sqrt(radical))/(2*a);
        vec4 q2 = point + (t3 * direction);
        vec4 n2 = vec4(2*q2.x,2*q2.y,2*(1-q2.z),0);
        if(q2.z>0 && q2.z<1){
            ts.push_back(t3);
            n.push_back(n2);
        }
    }



    if(!ts.empty())
    {
        real min = *min_element(ts.begin(), ts.end());
        if(min>=0)
        {
            hit_out.t=min;
            hit_out.material=material();
            hit_out.position = ray.p+(min*ray.d);
            int index=min_element(ts.begin(),ts.end())-ts.begin();
            vec4 norm=n[index];
            hit_out.normal = (transpose(transformInverse()))*norm;
            return true;
        }
        else
            return false;
    }

    return false;
}

bool Cube::rayIntersect( const ray3& ray, Intersection& hit_out ) const {
    // Your code goes here.

    // Remember that this intersection occurs in object-space.
    // You convert the world-space ray to object-space by multipling transformInverse() * ray.p and ray.d.
    // When filling out `hit_out`, don't forget to return the resulting position and normal in world-space.
    // For the normal, that means left-multiplying the object-space normal by transpose( transformInverse() ).
    std::vector<real>ts;
    std::vector<vec4>n;
    vec4 d = vec4(ray.d,0);
    vec4 p = vec4(ray.p,1);
    vec4 direction = transformInverse()*d;
    vec4 point = transformInverse()*p;

//X-plane
    real cx = point.x;
    real bx = direction.x;

    real t1 = -(1+cx)/bx;
    if(t1>=0){
        vec4 q1 = point + (t1 * direction);
        vec4 n1= vec4(-1,0,0,0);
        if (q1.z>=-1 && q1.z<=1 && q1.y>=-1 && q1.y<=1)
        {
            ts.push_back(t1);
            n.push_back(n1);
        }
    }

    real t2 =(1-cx)/bx;

    if(t2>=0){
        vec4 q2 = point + (t2 * direction);
        vec4 n2= vec4(1,0,0,0);
        if (q2.z>=-1 && q2.z<=1 && q2.y>=-1 && q2.y<=1)
        {
            ts.push_back(t2);
            n.push_back(n2);
        }
    }

//y-plane

    real cy = point.y;
    real by = direction.y;

    real t3 = -(1+cy)/by;
    if(t3>=0){
        vec4 q3 = point + (t3 * direction);
        vec4 n3= vec4(0,-1,0,0);
        if (q3.z>=-1 && q3.z<=1 && q3.x>=-1 && q3.x<=1)
        {
            ts.push_back(t3);
            n.push_back(n3);
        }
    }

    real t4 =(1-cy)/by;

    if(t4>=0){
        vec4 q4 = point + (t4 * direction);
        vec4 n4= vec4(0,1,0,0);
        if (q4.z>=-1 && q4.z<=1 && q4.x>=-1 && q4.x<=1)
        {
            ts.push_back(t4);
            n.push_back(n4);
        }
    }

//Z-plane

    real cz = point.z;
    real bz = direction.z;

    real t5 = (-(1+cz))/bz;
    if(t5>=0){
        vec4 q5 = point + (t5 * direction);
        vec4 n5= vec4(0,0,-1,0);
        if (q5.y>=-1 && q5.y<=1 && q5.x>=-1 && q5.x<=1)
        {
            ts.push_back(t5);
            n.push_back(n5);
        }
    }

    real t6 =(1-cz)/bz;

    if(t6>=0){
        vec4 q6 = point + (t6 * direction);
        vec4 n6= vec4(0,0,1,0);
        if (q6.y>=-1 && q6.y<=1 && q6.x>=-1 && q6.x<=1)
        {
            ts.push_back(t6);
            n.push_back(n6);
        }
    }

    if(!ts.empty())
    {
        real min = *min_element(ts.begin(), ts.end());
        if(min<0)
        {
            return false;

        }
        hit_out.t=min;
        hit_out.material=material();
        hit_out.position = ray.p+(min*ray.d);
        int index=min_element(ts.begin(),ts.end())-ts.begin();
        vec4 norm=n[index];
        hit_out.normal = (transpose(transformInverse()))*norm;
        return true;
    }




    return false;
}





bool Mesh::rayIntersect( const ray3& ray, Intersection& hit_out ) const {
    // Your code goes here.

    // Remember that this intersection occurs in object-space.
    // You convert the world-space ray to object-space by multipling transformInverse() * ray.p and ray.d.
    // When filling out `hit_out`, don't forget to return the resulting position and normal in world-space.
    // For the normal, that means left-multiplying the object-space normal by transpose( transformInverse() ).

    return false;
}

}


