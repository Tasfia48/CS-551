#include "airbrush.h"
#include <cassert>
#include <cmath> // sqrt(), lround()
#include <algorithm> // std::min(), std::max()

#include <iostream>



// Put helper functions needed by this file only here in an anonymous namespace.


namespace {
typedef double real;

using graphics101::AirBrushShape;
using graphics101::ColorRGBA8;

/*
     * Falloff functions take a parameter `t`, guaranteed to be greater than or equal to zero,
     * and return a number between 0 and 1.
     * The return value should be 1 at the center and fall off to 0 when t >= 1.
     */
real falloff_constant( real t )
{
    // Your code goes here.
    if(t<1)
        return 1;
    else
        return 0;
}

real falloff_linear( real t )
{
    // Your code goes here.

    if(t<1)
        return (1-t);
    else
        return 0;
}


real falloff_quadratic( real t )
{
    // Your code goes here.

    //assert( t >= 0. );
    if(t<1/3)
        return (1-(3*t*t));
    else if (t<1)
        return ((1.5*t*t)-(3*t)+1.5);
    else
        return 0;
}

real falloff_special( real t )
{
    // Your code goes here
    //assert( t >= 0. );
    if(t<0.2)
        return 1;
    else if(t>0.4 && t<0.5)
        return 1;
    else if(t>0.8 && t<0.9)
        return 1;
    else
        return 0;
}

real falloff( AirBrushShape shape, real t )
{
    using namespace graphics101;

    switch( shape ) {
    case Constant: return falloff_constant(t);
    case Linear: return falloff_linear(t);
    case Quadratic: return falloff_quadratic(t);
    case Special: return falloff_special(t);
    default:
        assert(!"Invalid AirBrushShape. We shouldn't be here.");
        return -1.;
    }
}


//inline int lerp( int a, int b, real t ) {
//    // Your code goes here.

//    t=t/255;
//    float com = a*t+b*(1-t);

//    com = round(com);

//    // Don't forget to round floating point numbers whose decimal part is >= 0.5 up.
//    return com;
//}



inline int lerp( int a, int b, int t ) {
    // Your code goes here.


    int com = a*t+b*(256-t);
    com = com>>8;
    //com = round(com);

    // Don't forget to round floating point numbers whose decimal part is >= 0.5 up.
    return com;
}




inline ColorRGBA8 composite( const ColorRGBA8& foreground, const ColorRGBA8& background ) {

    int red = lerp(foreground.r,background.r,foreground.a);
    int green = lerp(foreground.g,background.g,foreground.a);
    int blue = lerp(foreground.b,background.b,foreground.a);

    // Your code goes here.

    return ColorRGBA8(
                // red
                red,
                // green
                green,
                // blue
                blue
                );
}
}

namespace graphics101
{
void create_airbrush( Image& airbrush_out, AirBrushShape shape, int radius, ColorRGBA8 color )
{
    assert( radius >= 0 );

    // Step 1. Allocate space for the mask. Make a color image with 8 bits for red, green, blue, and alpha.
    const int size = 1+2*radius;
    if( airbrush_out.width() != size || airbrush_out.height() != size ) {
        airbrush_out.resize( size, size );
    }


    // Step 2. Set the RGB contents of the image to the `color`'s RGB values.
    //         Set the alpha channel of the image to `color.a` scaled by the appropriate falloff.

    // Your code goes here.
    int x0= airbrush_out.width()/2;
    int y0 = airbrush_out.height()/2;

    airbrush_out.fill(color);

    for(int x=0;x<airbrush_out.width();x++){

        for(int y=0;y<airbrush_out.height();y++){

            float t = sqrt(((x-x0)*(x-x0))+(y-y0)*(y-y0))/radius;
            airbrush_out.pixel(x,y).a= (color.a)*falloff(shape,t);
        }

    }

    // For debugging, this may be useful:
    airbrush_out.save( "airbrush.png" );
    // On a Mac, the file may be in "airbrush.app/Contents/MacOS/airbrush.png".
    // You can right-click or control-click on "airbrush.app"
    // and choose "Show Package Contents" to see inside.
}

Rect paint_at( Image& image_to_modify,
               const Image& airbrush_image,
               int center_x,
               int center_y
               )
{

    // Your code goes here.


    assert( airbrush_image.width() % 2 == 1 );
    assert( airbrush_image.height() % 2 == 1 );
    assert( airbrush_image.width() == airbrush_image.height() );


    const int radius = airbrush_image.width()/2;

    // Step 1. Compute the start and end offsets into `image_to_modify` and `airbrush_image`
    //         that you will iterate over.


    int w1 = center_x-radius;
    if(w1<0)
        w1=0;

    int w2 = center_x+radius;
    if(w2>image_to_modify.width())
        w2=image_to_modify.width();
    int h1 = center_y-radius;
    if(h1<0)
        h1=0;
    int h2 = center_y+radius;
    if(h2>image_to_modify.height())
        h2=image_to_modify.height();

    for(int x=w1;x<w2;x++){

        for(int y=h1;y<h2;y++){

            int wt = center_x-radius;
            int ht = center_y-radius;
            image_to_modify.pixel(x,y)=composite(airbrush_image.pixel(x-wt,y-ht),image_to_modify.pixel(x,y));


        }
    }

    // Step 2. Modify `image_to_modify` pixels by compositing `airbrush_image`.

    // Step 3. Return the rectange dimensions of the part of `image_to_modify` that was modified
    //         as a Rect.
    return Rect( w1, h1, w2, h2 );
}
std::string StringFromAirBrushShape( AirBrushShape shape ) {
    switch( shape ) {
    case Constant: return "Constant";
    case Linear: return "Linear";
    case Quadratic: return "Quadratic";
    case Special: return "Special";
    default:
        assert(!"Invalid AirBrushShape. We shouldn't be here.");
        return "Special";
    }
}

AirBrushShape AirBrushShapeFromString( const std::string& str ) {
    if( str == "Constant" ) return Constant;
    else if( str == "Linear" ) return Linear;
    else if( str == "Quadratic" ) return Quadratic;
    else if( str == "Special" ) return Special;
    else {
        assert(!"Invalid AirBrushShape. We shouldn't be here.");
        return Special;
    }
}
}
