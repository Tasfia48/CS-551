#include "shape.h"

#include "debugging.h"

#include <cmath> // std::sin(), std::cos()

using namespace glm;

namespace graphics101 {

void Cylinder::tessellate( Mesh& mesh )
{
    mesh.clear();

    for (int i=0;i< m_slices; i++)
    {
        float u=float(i)/m_slices;
        for (int j=0;j<m_stacks;j++)
        {
            real v=float(j)/(m_stacks-1);
            real p=2*pi*u;
            real z=v;
            real x=1*cos(p);
            real y=1*sin(p);
            mesh.positions.push_back(vec3(x,y,z));
            mesh.normals.push_back(vec3(x,y,0));

            if (i>0  && j>0)
            {
                mesh.face_positions.push_back(vec3((m_stacks*i)+j,(m_stacks*(i-1))+j,(m_stacks*(i-1))+(j-1)));
                mesh.face_positions.push_back(vec3((m_stacks*i)+j,(m_stacks*(i-1))+(j-1),(m_stacks*i)+(j-1)));
                mesh.face_normals.push_back(vec3((m_stacks*i)+j,(m_stacks*(i-1))+j,(m_stacks*(i-1))+(j-1)));
                mesh.face_normals.push_back( vec3((m_stacks*i)+j,(m_stacks*(i-1))+(j-1),(m_stacks*i)+(j-1)) );
            }
            if(j>0 && i == m_slices-1)
            {
                mesh.face_positions.push_back(vec3((m_stacks*0)+j,(m_stacks*(i))+j,(m_stacks*(i))+(j-1)));
                mesh.face_positions.push_back(vec3((m_stacks*0)+j,(m_stacks*(i))+(j-1),(m_stacks*0)+(j-1)));
                mesh.face_normals.push_back( vec3((m_stacks*0)+j,(m_stacks*(i))+j,(m_stacks*(i))+(j-1)) );
                mesh.face_normals.push_back( vec3((m_stacks*0)+j,(m_stacks*(i))+(j-1),(m_stacks*0)+(j-1)) );
            }

        }
    }
}

void Sphere::tessellate( Mesh& mesh )
{
    mesh.clear();
    for (int i=0;i< m_slices; i++)
    {
        real u=float(i)/(m_slices);

        for (int j=0;j<m_stacks;j++)
        {
            real v=float(j)/(m_stacks-1);
            real p=2*pi*u;
            real t=pi*v;
            real z=1*cos(t);
            real x=1*sin(t)*cos(p);
            real y=1*sin(t)*sin(p);
            mesh.positions.push_back(vec3(x,-y,z));
            mesh.normals.push_back(vec3(x,-y,z));
            if (i>0 && j>0)
            {
                mesh.face_positions.push_back(vec3(m_stacks*i+j,m_stacks*(i-1)+j,m_stacks*(i-1)+j-1));
                mesh.face_positions.push_back(vec3(m_stacks*i+j,m_stacks*(i-1)+j-1,m_stacks*i+j-1));
                mesh.face_normals.push_back(vec3(m_stacks*i+j,m_stacks*(i-1)+j,m_stacks*(i-1)+j-1));
                mesh.face_normals.push_back(vec3(m_stacks*i+j,m_stacks*(i-1)+j-1,m_stacks*i+j-1));
            }

            if(i==m_slices-1 &&j>0)
            {
                mesh.face_positions.push_back(vec3((m_stacks*0)+j,(m_stacks*(i))+j,(m_stacks*(i))+(j-1)));
                mesh.face_positions.push_back(vec3((m_stacks*0)+j,(m_stacks*(i))+(j-1),(m_stacks*0)+(j-1)));
                mesh.face_normals.push_back(vec3((m_stacks*0)+j,(m_stacks*(i))+j,(m_stacks*(i))+(j-1)));
                mesh.face_normals.push_back(vec3((m_stacks*0)+j,(m_stacks*(i))+(j-1),(m_stacks*0)+(j-1)));
            }
        }
    }

}

void Cone::tessellate( Mesh& mesh )
{
    mesh.clear();
    for (int i=0;i< m_slices; i++)
    {
        float u=float(i)/m_slices;
        for (int j=1;j<m_stacks;j++)
        {
            //            float v=float(j)/(m_stacks-1);
            float phi=2*pi*u;
            //            float z=v;
            //            float x=1*cos(phi);
            //            float y=1*sin(phi);
            float theta1=(float(j)/(m_stacks-1)) *pi;
            real r=1;
            real x=r*sin(theta1)*  cos(phi);
            real y= r *sin(theta1)*sin(phi);
            real z = r*cos(theta1);
            mesh.positions.push_back(vec3(x,-y,z));
            mesh.normals.push_back(vec3(x,-y,z));
            //            mesh.positions.push_back(vec3(x,y,z));
            //            mesh.normals.push_back(vec3(x,y,0));

            if (i>0  && j>0)
            {
                mesh.face_positions.push_back(vec3((m_stacks*i)+j,(m_stacks*(i-1))+j,(m_stacks*(i-1))+(j-1)));
                mesh.face_positions.push_back(vec3((m_stacks*i)+j,(m_stacks*(i-1))+(j-1),(m_stacks*i)+(j-1)));
                mesh.face_normals.push_back(vec3((m_stacks*i)+j,(m_stacks*(i-1))+(j-1),(m_stacks*i)+(j-1)));
                mesh.face_normals.push_back( vec3((m_stacks*i)+j,(m_stacks*(i-1))+(j-1),(m_stacks*i)+(j-1)) );
            }
            if(i == m_slices-1 && j>0)
            {
                mesh.face_positions.push_back(vec3((m_stacks*0)+j,(m_stacks*(i))+j,(m_stacks*(i))+(j-1)));
                mesh.face_positions.push_back(vec3((m_stacks*0)+j,(m_stacks*(i))+(j-1),(m_stacks*0)+(j-1)));
                mesh.face_normals.push_back( vec3((m_stacks*0)+j,(m_stacks*(i))+j,(m_stacks*(i))+(j-1)) );
                mesh.face_normals.push_back( vec3((m_stacks*0)+j,(m_stacks*(i))+(j-1),(m_stacks*0)+(j-1)) );
            }

        }


    }//       m_slices=m_slices-1;


    // Your code goes here.
}

void Torus::tessellate( Mesh& mesh )
{
    mesh.clear();

    // Your code goes here.
}

void Cube::tessellate( Mesh& mesh )
{
    mesh.clear();
    for (int xi=0;xi<m_slices_edge;xi++)
    {   float x= float(x)/m_slices_edge;
        for (int yi=0;yi<m_slices_edge;yi++)
        {
            float y= float(y)/m_slices_edge;
            mesh.positions.push_back(vec3(x,y,1));
        }
    }

    // Your code goes here.
}

}
