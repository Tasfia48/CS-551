#include "convolution.h"
#include <cassert>
#include <cstdlib>
#include <cmath>
#include <functional> // std::function
#include <vector>

using namespace graphics101;

namespace {
// Returns `value` clamped to lie in the range [min,max].
template< typename T >
inline T clamp( const T& value, const T& min, const T& max ) {
    return std::min( max, std::max( min, value ) );
}

// Your helper functions go here.

// NOTE: These are only suggestions!
// void convolve1D( int length, const ColorRGBA8* input, int input_stride, ColorRGBA8* output, int output_stride, const std::vector< int >& filter, bool normalize = true ) {}
// void resample1D( const ColorRGBA8* input, int input_length, int input_stride, ColorRGBA8* output, int output_length, int output_stride, const std::function<real(real)>& filter, real filter_radius, bool normalize = true ) {}

// To use this as a function taking only the x parameter, wrap it in a "lambda".
//     real radius = 2.0;
//     auto triangle_without_radius_parameter = [radius]( real x ) { return triangle( radius, x ); }
// Now we can call:
//     triangle_without_radius_parameter( x );
// or pass `triangle_without_radius_parameter` as an argument to a function taking a
// std::function<real(real)> parameter.

inline real triangle( real radius2, real x ) {
    // Your code goes here.
    real temp=1-abs(x/radius2);
    return std::max(real(0),temp);
}
inline real triangle_without_radius_parameter(real x ) {
    real radius = 2.0;
    return triangle(radius,x);
}

}

namespace graphics101 {

// Converts each pixel to greyscale, saving the result into `output`.
void greyscale( const Image& input, Image& output ) {

    // Your code goes here.

    // Allocate an output image the same size as the input.
    output = Image( input.width(), input.height() );

    // Three ways to write it:
    // 1 Using input.pixel() and output.pixel()
    // 2 Using scanline() to iterate over rows.
    // 3 Using scanline() to iterate over columns.
    // I have written all three below.


    // 1 Using input.pixel()
    for( int j = 0; j < input.height(); ++j ) {
        for( int i = 0; i < input.width(); ++i ) {
            // The pixel() method gives direct access to the pixel at row i and column j.
            const ColorRGBA8 pix = input.pixel( i,j );

            // The grey value is just the average of red, green, and blue.
            // Perceptually, green is more important, but this is a fine approximation.
            const int grey = ( pix.r + pix.g + pix.b )/3;

            output.pixel( i,j ) = ColorRGBA8( grey, grey, grey );
        }
    }


    // 2 Using scanline() to iterate over each row.
    for( int j = 0; j < input.height(); ++j ) {

        // Get a pointer to the pixels in each row.
        // Pixels in a row are adjacent.
        // Pixels in a column are separated by a stride of input.width().
        const ColorRGBA8* row_in = input.scanline( j );
        const int stride_in = 1;

        ColorRGBA8* row_out = output.scanline( j );
        const int stride_out = 1;

        for( int i = 0; i < input.width(); ++i ) {
            // To access the i-th pixel, multiply i by the stride.
            const ColorRGBA8 pix = row_in[ i*stride_in ];

            // The grey value is just the average of red, green, and blue.
            // Perceptually, green is more important, but this is a fine approximation.
            const int grey = ( pix.r + pix.g + pix.b )/3;

            row_out[ i*stride_out ] = ColorRGBA8( grey, grey, grey );
        }
    }


    // 3 Using scanline() to iterate over each column.
    for( int i = 0; i < input.width(); ++i ) {

        // Get a pointer to the pixels in each column.
        // Pixels in a row are adjacent.
        // Pixels in a column are separated by a stride of input.width().
        const ColorRGBA8* col_in = input.scanline(0) + i;
        const int stride_in = input.width();

        ColorRGBA8* col_out = output.scanline(0) + i;
        const int stride_out = output.width();

        for( int j = 0; j < input.height(); ++j ) {
            // To access the j-th pixel, multiply j by the stride.
            const ColorRGBA8 pix = col_in[ j*stride_in ];

            // The grey value is just the average of red, green, and blue.
            // Perceptually, green is more important, but this is a fine approximation.
            const int grey = ( pix.r + pix.g + pix.b )/3;

            col_out[ j*stride_out ] = ColorRGBA8( grey, grey, grey );
        }
    }
}

// Subtracts `input1` from `input2`, saving the absolute value of the result into `output`.
// This function assumes that the dimensions of input1 and input2 match.
void difference( const Image& input1, const Image& input2, Image& output ) {
    assert( input1.width() == input2.width() );
    assert( input1.height() == input2.height() );

    // Your code goes here.

    // Allocate an output image the same size as the input.
    output = Image( input1.width(), input1.height() );

    // 1 Using input.pixel()
    for( int j = 0; j < input1.height(); ++j ) {
        for( int i = 0; i < input1.width(); ++i ) {
            const ColorRGBA8 pix1 = input1.pixel( i,j );
            const ColorRGBA8 pix2 = input2.pixel( i,j );

            const int rdiff = abs( int( pix1.r ) - int( pix2.r ) );
            const int gdiff = abs( int( pix1.g ) - int( pix2.g ) );
            const int bdiff = abs( int( pix1.b ) - int( pix2.b ) );

            output.pixel( i,j ) = ColorRGBA8( rdiff, gdiff, bdiff );
        }
    }
}

// Applies a box blur with `radius` to `input`, saving the result
// into `output`.
void blur_box( const Image& input, int radius, Image& output ) {
    assert( radius >= 0 );

    // Your code goes here.
    assert( radius >= 0 );


    Image intermediate= input;
    output = Image( input.width(), input.height() );

    for (int x=0;x<input.width();x++)
    {
        for (int y=0;y<input.height();y++)
        {

            float red=0;
            float green=0;
            float blue=0;
            int count=0;
            for (int i = -radius; i <= radius; i++)
            {

                if(x+i>=0 && x+i<input.width())
                {
                    ColorRGBA8 temp = input.pixel(x+i,y);
                    red=red+temp.r;
                    blue=blue+temp.b;
                    green =green+temp.g;
                    count++;
                }

            }
            float red_avg=red/count;
            float blue_avg=blue/count;
            float green_avg=green/count;
            float r = std::max( float(0), std::min( float(255), red_avg ));
            float g = std::max( float(0), std::min( float(255), green_avg ));
            float b = std::max( float(0), std::min( float(255), blue_avg ));

            intermediate.pixel(x,y)=ColorRGBA8( r,g,b );

        }
    }


    for (int x=0;x<intermediate.width();x++)
    {
        for (int y=0;y<intermediate.height();y++)
        {
            float red=0;
            float green=0;
            float blue=0;
            int count=0;
            for (int i = -radius; i <= radius; i++)
            {
                if(y+i>=0 && y+i<intermediate.height())
                {
                    ColorRGBA8 temp = intermediate.pixel(x,y+i);
                    red=red+temp.r;
                    blue=blue+temp.b;
                    green = green+temp.g;
                    count++;
                }
            }
            float red_avg=red/count;
            float blue_avg=blue/count;
            float green_avg=green/count;
            float r = std::max( float(0), std::min( float(255), red_avg ));
            float g = std::max( float(0), std::min( float(255), green_avg ));
            float b = std::max( float(0), std::min( float(255), blue_avg ));

            output.pixel(x,y)=ColorRGBA8( r,g,b );

        }
    }
}

// Scales the `input` image to the new dimensions, saving the result
// into `output`.

//void scale( const Image& input, int new_width, int new_height, Image& output ) {
//    assert( input.width() > 0 );
//    assert( input.height() > 0 );
//    assert( new_width > 0 );
//    assert( new_height > 0 );
//    //Radius for height and width
//    int dx=1;
//    int dy=1;
//    output = Image(new_width, new_height);

//    if(new_width<input.width())
//    {
//        dx= input.width()/new_width;
//    }
//    if(new_height<input.height())
//    {
//        dy= input.height()/new_height;
//    }

//    real xl=-0.5;
//    real xw=input.width()-0.5;
//    real xh=input.height()-0.5;

//    real delW=(xw-xl)/new_width;
//    real delH=(xh-xl)/new_height;
//    real x0W=xl+(delW/2);
//    real x0H=xl+(delH/2);

//    for (int i=0;i<new_width;++i)
//    {
//        for (int j=0;j<new_height;++j)
//        {
//            real numeratorR = 0;
//            real numeratorG = 0;
//            real numeratorB = 0;
//            real denominatorR = 0;
//            real denominatorG = 0;
//            real denominatorB = 0;
//            real y= x0H+(j*delH);
//            real x= x0W+(i*delW);
//            real maxH =floor(y+dy);
//            real minH= ceil(y-dy);
//            real maxW= floor(x+dx);
//            real minW= ceil(x-dx);

//            if( (minW>=0 && maxW <input.width()) && (minH>=0 && maxH <input.height())){
//                for (int w=minW;w<maxW; w++)
//                {
//                    for (int h=minH;h<maxH; h++)
//                    {
//                        real filter = triangle(dy,y-h)*triangle(dx,x-w);
//                        ColorRGBA8 imagePixel = input.pixel(w,h);

//                        numeratorR=numeratorR+(imagePixel.r*filter);
//                        numeratorG=numeratorG+(imagePixel.g*filter);
//                        numeratorB=numeratorB+(imagePixel.b*filter);
//                        denominatorR=denominatorR+ filter;
//                        denominatorG=denominatorG+ filter;
//                        denominatorB=denominatorB+ filter;
//                    }
//                }

//        }

//        float red_avg=numeratorR/denominatorR;
//        float green_avg=numeratorG/denominatorG;
//        float blue_avg=numeratorB/denominatorB;
//        float r = std::max( float(0), std::min( float(255), red_avg ));
//        float g = std::max( float(0), std::min( float(255), green_avg ));
//        float b = std::max( float(0), std::min( float(255), blue_avg ));

//        output.pixel(i,j)=ColorRGBA8( r, g, b );
//        }
//    }

//}


// Convolves the `input` image with `filter`, saving the result into `output`.
// NOTE: This function assumes that `filter` is greyscale (has the same
//       values for red, green, and blue).
void convolve( const Image& input, const Image& filter, Image& output ) {
    // We assume that the filter is all gray.

    // Your code goes here.
    output = Image( input.width(), input.height());
    const Image mirrorfilter=Image(filter).flip().mirror();

    int dx=mirrorfilter.width()/2;
    int dy=mirrorfilter.height()/2;

    for (int y=0; y<input.height(); y++)
    {
        for (int x=0; x<input.width(); x++)

        {

            real numeratorR = 0;
            real numeratorG = 0;
            real numeratorB = 0;
            real denominatorR = 0;
            real denominatorG = 0;
            real denominatorB = 0;
            for (int h=0;h< mirrorfilter.height(); h++)
            {
                for (int w=0;w<mirrorfilter.width();w++)

                {
                    int i = x-dx + w;
                    int j = y-dy + h;
                    if((i>=0 && i<input.width()) && (j>=0 && j<input.height()))
                    {
                        ColorRGBA8 imagePixel = input.pixel(i,j);
                        ColorRGBA8 filterPixel = mirrorfilter.pixel(w,h);

                        numeratorR=numeratorR+(imagePixel.r*filterPixel.r);
                        numeratorG=numeratorG+(imagePixel.g*filterPixel.g);
                        numeratorB=numeratorB+(imagePixel.b*filterPixel.b);
                        denominatorR=denominatorR+filterPixel.r;
                        denominatorG=denominatorG+filterPixel.g;
                        denominatorB=denominatorB+filterPixel.b;

                    }
                }

            }

            float red_avg=numeratorR/denominatorR;
            float green_avg=numeratorG/denominatorG;
            float blue_avg=numeratorB/denominatorB;
            float r = std::max( float(0), std::min( float(255), red_avg ));
            float g = std::max( float(0), std::min( float(255), green_avg ));
            float b = std::max( float(0), std::min( float(255), blue_avg ));
            output.pixel(x,y)=ColorRGBA8( r, g, b );

        }
    }
}

// Sharpens the `input` image by moving `amount` away from a blur with `radius`.
// Saves the result into `output`.
void sharpen( const Image& input, real amount, int radius, Image& output ) {
    assert( radius >= 0 );
    int r =radius;
    output = Image( input.width(), input.height() );
    Image intermediate = Image( input.width(), input.height() );
    blur_box(input,r,intermediate);
    for( int j = 0; j < input.height(); ++j ) {
        for( int i = 0; i < input.width(); ++i ) {
            const ColorRGBA8 pix1 = input.pixel( i,j );
            const ColorRGBA8 pix2 = intermediate.pixel( i,j );
            int a=amount;
            int b= 1+amount;

            const int rdiff = ( (b*int( pix1.r )) - (a*int( pix2.r )));
            int red = std::max( 0, std::min( 255, rdiff ));
            const int gdiff = ( (b*int( pix1.g )) - (a*int( pix2.g )));
            int green = std::max( 0, std::min( 255, gdiff ));
            const int bdiff = ( (b*int( pix1.b )) - (a*int( pix2.b )));
            int blue = std::max( 0, std::min( 255, bdiff));

            output.pixel( i,j ) = ColorRGBA8( red, green, blue );
        }
    }
}

// Performs edge detection on the `input` image. Stores the result into `output`.
void edge_detect( const Image& input, Image& output ) {

    output = Image( input.width(), input.height() );
    Image Dx = Image( input.width(), input.height() );
    Image Dy = Image( input.width(), input.height() );
    std::vector<int> filter;
    filter.push_back(-1);
    filter.push_back(0);
    filter.push_back(1);
    int radius = (filter.size()/2);

    for (int y=0;y<input.height();y++)
    {
        for (int x=0;x<input.width();x++)
        {

            real numeratorR = 0;
            real numeratorG = 0;
            real numeratorB = 0;


            for (int l = 0; l <3 ; l++)
            {
                int i = x - radius + l;

                if(i>=0 && i<input.width())
                {
                    ColorRGBA8 temp = input.pixel(i,y);
                    numeratorR=numeratorR+(temp.r*(filter[l]));
                    numeratorG=numeratorG+(temp.g*(filter[l]));
                    numeratorB =numeratorB+(temp.b*(filter[l]));

                }

            }
            float red_avg=abs(numeratorR);
            float green_avg=abs(numeratorG);
            float blue_avg=abs(numeratorB);

            float r = std::max( float(0), std::min( float(255), red_avg ));
            float g = std::max( float(0), std::min( float(255), green_avg ));
            float b = std::max( float(0), std::min( float(255), blue_avg ));

            Dx.pixel(x,y)=ColorRGBA8( r,g,b );

        }
    }


    for (int x=0;x<input.width();x++)
    {
        for (int y=0;y<input.height();y++)
        {
            real numeratorR = 0;
            real numeratorG = 0;
            real numeratorB = 0;

            for (int l = 0; l <3 ; l++)
            {
                int i = y - radius + l;

                if(i>=0 && i<input.height())
                {
                    ColorRGBA8 temp = input.pixel(x,i);
                    numeratorR=numeratorR+(temp.r*filter[l]);
                    numeratorG=numeratorG+(temp.g*filter[l]);
                    numeratorB =numeratorB+(temp.b*filter[l]);
                }

            }
            float red_avg=abs(numeratorR);
            float green_avg=abs(numeratorG);
            float blue_avg=abs(numeratorB);
            float r = std::max( float(0), std::min( float(255), red_avg ));
            float g = std::max( float(0), std::min( float(255), green_avg ));
            float b = std::max( float(0), std::min( float(255), blue_avg ));

            Dy.pixel(x,y)=ColorRGBA8( r,g,b );

        }
    }
    for(int k=0;k<input.width();k++)
    {
        for(int l=0;l<input.height();l++)
        {
            float red = std::sqrt(pow((Dx.pixel(k,l).r),2)+pow((Dy.pixel(k,l).r),2));
            float green =std::sqrt(pow((Dx.pixel(k,l).g),2)+pow((Dy.pixel(k,l).g),2));
            float blue = std::sqrt(pow((Dx.pixel(k,l).b),2)+pow((Dy.pixel(k,l).b),2));
            float r = std::max( float(0), std::min( float(255), red ));
            float g = std::max( float(0), std::min( float(255), green ));
            float b = std::max( float(0), std::min( float(255), blue ));
            output.pixel(k,l)=ColorRGBA8( r, g, b );
        }
    }
}



void scale( const Image& input, int new_width, int new_height, Image& output ) {
    assert( input.width() > 0 );
    assert( input.height() > 0 );
    assert( new_width > 0 );
    assert( new_height > 0 );

    int dx=1;
    int dy=1;
    output = Image(new_width, new_height);
    Image intermediate= Image(input.width(),new_height);

    if(new_width<input.width())
    {
        dx= input.width()/new_width;
    }
    if(new_height<input.height())
    {
        dy= input.height()/new_height;
    }

    real xl=-0.5;
    real xw=input.width()-0.5;
    real xh=input.height()-0.5;

    real delW=(xw-xl)/new_width;
    real delH=(xh-xl)/new_height;
    real x0W=xl+(delW/2);
    real x0H=xl+(delH/2);


    for (int i=0;i<input.width();i++)
    {
        for (int j=0;j<new_height;j++)
        {
            real numeratorR = 0;
            real numeratorG = 0;
            real numeratorB = 0;
            real denominatorR = 0;
            real denominatorG = 0;
            real denominatorB = 0;
            real y= x0H+(j*delH);
            real maxH =ceil(y+dy);
            real minH= floor(y-dy);

            if( minH>=0 && maxH <input.height() )
            {
                for (int h=minH;h<maxH; h++)

                {

                    real filter = triangle(dy,y-h);
                    ColorRGBA8 imagePixel = input.pixel(i,h);

                    numeratorR=numeratorR+(imagePixel.r*filter);
                    numeratorG=numeratorG+(imagePixel.g*filter);
                    numeratorB=numeratorB+(imagePixel.b*filter);
                    denominatorR=denominatorR+ filter;
                    denominatorG=denominatorG+ filter;
                    denominatorB=denominatorB+ filter;


                }


            }

            float red_avg=numeratorR/denominatorR;
            float green_avg=numeratorG/denominatorG;
            float blue_avg=numeratorB/denominatorB;
            float r = std::max( float(0), std::min( float(255), red_avg ));
            float g = std::max( float(0), std::min( float(255), green_avg ));
            float b = std::max( float(0), std::min( float(255), blue_avg ));
            intermediate.pixel(i,j)=ColorRGBA8( r, g, b );

        }


    }



    for (int i=0;i<new_width;i++)
    {
        for (int j=0;j<new_height;j++)
        {
            real numeratorR = 0;
            real numeratorG = 0;
            real numeratorB = 0;
            real denominatorR = 0;
            real denominatorG = 0;
            real denominatorB = 0;
            real x= x0W+(i*delW);
            real maxW= ceil(x+dx);
            real minW= floor(x-dx);
            if( minW>=0 && maxW <intermediate.width())
            {
                for (int w=x-dx;w<x+dx; w++)

                {
                    real filter = triangle(dx,x-w);
                    ColorRGBA8 imagePixel = intermediate.pixel(w,j);

                    numeratorR=numeratorR+(imagePixel.r*filter);
                    numeratorG=numeratorG+(imagePixel.g*filter);
                    numeratorB=numeratorB+(imagePixel.b*filter);
                    denominatorR=denominatorR+ filter;
                    denominatorG=denominatorG+ filter;
                    denominatorB=denominatorB+ filter;
                }


            }


            float red_avg=numeratorR/denominatorR;
            float green_avg=numeratorG/denominatorG;
            float blue_avg=numeratorB/denominatorB;
            float r = std::max( float(0), std::min( float(255), red_avg ));
            float g = std::max( float(0), std::min( float(255), green_avg ));
            float b = std::max( float(0), std::min( float(255), blue_avg ));

            output.pixel(i,j)=ColorRGBA8( r, g, b );

        }



    }
}
}



