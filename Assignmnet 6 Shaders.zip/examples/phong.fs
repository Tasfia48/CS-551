#version 330

// Eye-space.
in vec3 fPos;
in vec3 fNormal;
in vec2 fTexCoord;

uniform mat3 uNormalMatrix;
uniform mat4 uViewMatrix;

uniform samplerCube uEnvironmentTex;

uniform struct Material {
    vec3 color_ambient;
    vec3 color_diffuse;
    vec3 color_specular;
    float shininess;

    bool reflective;
    vec3 color_reflect;

    bool refractive;
    vec3 color_refract;
    float index_of_refraction;

    bool use_diffuse_texture;
    sampler2D diffuse_texture;
} material;

struct Light {
    // Eye-space.
    vec3 position;
    vec3 color;
    vec3 color_ambient;
};
const int MAX_LIGHTS = 5;
uniform Light lights[ MAX_LIGHTS ];

uniform int num_lights;

// gl_FragColor is old-fashioned, but it's what WebGL 1 uses.
// From: https://stackoverflow.com/questions/9222217/how-does-the-fragment-shader-know-what-variable-to-use-for-the-color-of-a-pixel
layout(location = 0) out vec4 FragColor;

void main()
{
    // Your code goes here.
    vec3 total=vec3(0);
    vec3 N= normalize(fNormal);
    vec3 V = normalize(vec3(0)-fPos);



    for( int i =0;i<num_lights;i++ )
    {
        Light light = lights[i];

        //Ambient Lighting
        vec3 ambientLight= material.color_ambient*light.color_ambient;
        vec3 diffuse;

        //Diffuse lighting
        vec3 L  = normalize(light.position-fPos);
        float NL = max(dot(L,N),float(0));
//        float NL = dot(L,N);
        if(material.use_diffuse_texture)
        {
         diffuse = material.color_diffuse *vec3(texture(material.diffuse_texture,fTexCoord));
        }
        else
        {
        diffuse = material.color_diffuse;
        }
        vec3 diffuseLight = diffuse*light.color*NL;

        //specular lighting
        vec3 N= normalize(fNormal);
        vec3 R= -(normalize(L - (2*dot(L,N)*N)));
        float VR = max(dot(V,R),float(0));
        float n = material.shininess;
        vec3 specularLight = material.color_specular * light.color * pow(VR,n);


       if(NL>0)
       {
          if(VR>0)
          {
           total=total+ambientLight+(specularLight+diffuseLight);
           }
           else
           total=total+ambientLight+diffuseLight;

       }

       else
       {
           total=total+(ambientLight);
       }
    }


   if(material.reflective)
   {
       vec3 pos = vec3(0)-fPos;
       vec3 reflected= -(normalize(pos - (2*dot(pos,N)*N)));
       vec3 direction = vec3(normalize(transpose(uNormalMatrix)*reflected));
       vec3 IR = vec3(texture(uEnvironmentTex,direction));
       total =  total + (IR*material.color_reflect);
   }


    if(material.refractive)
    {
        vec3 pos = vec3(0)-fPos;
        vec3 refracted= normalize(refract(pos,fNormal,material.index_of_refraction));
        vec3 direction = vec3(normalize(transpose(uNormalMatrix)*(refracted)));
        vec3 IR = vec3(texture(uEnvironmentTex,direction));
        total =  total + (IR*material.color_refract);
    }




    FragColor = vec4( total, 1.0 );
}
