#include "scene.h"
#include "camera.h"
//Include all of glm here.
#include "glm/glm.hpp"

#include "debugging.h"

namespace graphics101 {

void Scene::render( Image& into_image ) {
    // Your code goes here.

    // Iterate over the pixels of the image. For each pixel:
    // 1. Use camera->getPixelUV() and camera->getRay() to create a ray3.
    // 2. Call rayColor() to get a vec3 color for that ray.
    // 3. Use into_image.pixel() to set the pixel color.
    for(int i=0;i<into_image.width();i++)
    {
        for(int j=0;j<into_image.height();j++)
        {
            vec2 uv= camera->getPixelUV(vec2(i,j),into_image.width(),into_image.height());
            ray3 r = camera->getRay(uv);
            vec3 col = rayColor(r,3);
            vec3 color=glm::clamp(col,vec3(0),vec3(1));
            into_image.pixel(i,j).r=color.r*255;
            into_image.pixel(i,j).g=color.g*255;
            into_image.pixel(i,j).b=color.b*255;
            into_image.pixel(i,j).a=255;
        }
    }
}

bool Scene::closestIntersection( const ray3& ray, Intersection& hit_out ) const {
    // Your code goes here.
    // Iterate over all the shapes, calling rayIntersect() on each.
    // In C++, a nice iterator for loop can be written as:
    // for( const ShapePtr shape: shapes ) { ... shape->rayIntersect( ... ) ... }

    Intersection hit;
    Intersection hit1;
    hit1.t =999999999;
    for( const ShapePtr shape: shapes ) {
        if(shape->rayIntersect(ray,hit))
        {
            if(hit.t<hit1.t)
                hit1=hit;
        }

    }
    if(hit1.t==999999999)
    {
        return false;
    }
    hit_out=hit1;
    if(hit_out.t>=0)
    {
        return true;
    }
    return false;
}


vec3 Scene::rayColor( const ray3& ray, int max_recursion ) const {
    // Your code goes here.

    // In this ray casting assignment, you will simply call closestIntersection(),
    // and, if there is one, return the .material.color_diffuse;
    // Otherwise, return black (0,0,0).


    assert( max_recursion >= 0 );
    const real eps = 1e-7;

    Intersection h;
    vec3 c( 0,0,0 );
    if(closestIntersection(ray,h)){
        vec3 total(0,0,0);
        vec3 N= glm::normalize(h.normal);


        for( const Light& l : lights )
        {

            //Ambient Lighting
            vec3 ambientLight= h.material.color_ambient*l.color_ambient;

            //Diffuse lighting
            vec3 L  = glm::normalize(l.position-h.position);
            real NL = std::max(dot(L,N),real(0));
            vec3 diffuseLight = h.material.color_diffuse*l.color*NL;

            //specular lighting
            vec3 V = glm::normalize(ray.p-h.position);
            vec3 N=  glm::normalize(h.normal);
            vec3 R= -(glm::normalize(L - (2*dot(L,N)*N)));
            real VR = std::max(dot(V,R),real(0));
            real n = h.material.shininess;
            vec3 specularLight = h.material.color_specular * l.color * pow(VR,n);

            //Shadows
            real Sl = 1;
            vec3 ldistance= (l.position-(h.position+vec3(eps)*L));
            real ldist=glm::length(ldistance);
            ray3 temp((h.position+vec3(eps)*L),L);
            Intersection i;
            if(closestIntersection(temp,i)==true)
            {
                real d= glm::length(i.position-h.position);
                if(d<ldist)
                {
                    Sl=0;
                }

            }

           if(NL>0)
           {
               total=total+ambientLight+(specularLight+diffuseLight)*Sl;
           }

           else
           {
               total=total+(ambientLight);
           }
        }

       if (max_recursion>0)

       {
           if(h.material.reflective)
           {
               vec3 pos = ray.p-h.position;
               vec3 reflected= -(glm::normalize(pos - (2*dot(pos,N)*N)));
               ray3 temp1(h.position+(vec3(eps)*reflected),reflected);
               return  total + (h.material.color_reflect * rayColor(temp1,max_recursion-1));
           }
           return rayColor(ray,max_recursion-1);
       }


        return total;
    }
    else
        return c;
}

}




